import React from "react";

const Favorites: React.FC = () => {
  return <h1>Hello from Favorites</h1>;
};

export default Favorites;
